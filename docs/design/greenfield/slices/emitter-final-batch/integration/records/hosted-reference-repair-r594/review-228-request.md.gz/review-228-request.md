Round 228 READ ONLY. Canonical /Users/hiramatsu/dev/tsc-rs-emitter-final-variable-producer-prep HEAD 277209358 with current bounded Python/fixture/noEmit gate repairs applied, no runtime source changed. Actual full acceptance-slice h2-7de is running; do not edit or run heavy builds. All five unchanged observer rewrites succeeded with every case payload identical (217 + 1798 + 1 + 68 + 4); only metadata hashes changed. Your r227 explicit emit-only noEmit gate fix applied branch-locally; ordinary prepared() unchanged, bounded Ok panic; pin audit clean.
NEW REAL RUNTIME FAILURE in hosted acceptance wide h2-5g (9027 cases): index 8368 typescript-6.0.3/conformance/types/import/importWithTypeArguments.ts#default. Original ts-tests file source: // @target: es2015
import<T>
const a = import<string, number>
. Expected JS CRLF: "use strict";
import;
const a = (import);
 ; actual: "use strict";
(import);
const a = ((import));
. Raw complete job log only31KB /tmp/emitter-final-hosted-progress-r577/106137452244.log. The 96MB late rawlog must NOT read.
Please independently trace likely faulty parentheses classification/ExpressionWithTypeArguments erasure versus upstream vendored 6.0.3, propose minimum safe runtime repair and adjacent tests especially import/new expressions, invalid syntax recovery, type argument erasure, comment/maps, shared parenthesizer blast radius. No speculative wide refactor; compare my coming analysis before commit. Need figure why full H25g green earlier historical does not prove current bytes. Inspect exact current code/upstream and existing relevant tests. READ ONLY no edits/mints/build. Return bounded concrete findings and affected files; local integrator will reproduce and add focused red/green then full actual h2-5g before new walk. Need all hidden follow-on errors in full band resolved before walk. User explicitly requests careful joint reasoning for high-impact/unknown changes.
