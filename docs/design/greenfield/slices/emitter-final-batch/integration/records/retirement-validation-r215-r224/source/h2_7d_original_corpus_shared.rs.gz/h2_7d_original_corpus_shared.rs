//! Original D and D/E candidates through ordinary production Program/command emission.
//! Frozen census/oracle membership is not an admission or a promised success count.
use std::collections::{BTreeMap, BTreeSet};
use std::path::{Path, PathBuf};

use base64::Engine;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use tsc_compiler::{MemoryOutputSink, ProgramSession};
use tsc_diagnostics::{Diagnostic, MessageChain};
use tsc_emitter::{EmitArtifact, EmitArtifactKind, EmitWriteMetadata};
use tsc_host::{CompilerHost, MemoryCompilerHost};
use tsc_program::{
    load_emitting_program, load_program, parse_config_root_plan, CompilerConfigHost,
    CompilerOptions, ConfigRootPlanRequest, LibraryCatalog, PreparedProgram, ProgramLoadError,
    ProgramLoadLimits, ProgramLoadOperation, ProgramOptions, ProgramPath,
};

const SOURCE_COMMIT: &str = "050880ce59e30b356b686bd3144efe24f875ebc8";
const CENSUS: (&str, &str) = (
    "ratchets/h2-7de-candidates.v1.json",
    "956514a27a7c9d4504f2bd364f07492b758660c4c6d525201ba62d1389a04db2",
);
const INPUTS: (&str, &str) = (
    "ratchets/h2-7de-candidate-inputs.v1.json",
    "f2e078a6b6d10cd3c6df833584924c18e8f78fe98c1e41621c70e10e215a073a",
);
const ORACLE: (&str, &str) = (
    "ratchets/h2-7de-observations.v1.json",
    "ef68d9021d7bde36eba86abb44b780418106aa44b6d9cbacca427d5edb9d74d9",
);

fn workspace() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR")).join("../..")
}

fn digest(bytes: impl AsRef<[u8]>) -> String {
    format!("{:x}", Sha256::digest(bytes.as_ref()))
}

fn frozen((path, hash): (&str, &str)) -> Value {
    let bytes = std::fs::read(workspace().join(path)).unwrap();
    assert_eq!(digest(&bytes), hash, "frozen {path}");
    let value: Value = serde_json::from_slice(&bytes).unwrap();
    assert_eq!(value["typescript"], "6.0.3");
    assert_eq!(value["source_commit"], SOURCE_COMMIT);
    value
}

fn indexed(artifact: &Value) -> BTreeMap<&str, &Value> {
    let rows = artifact["cases"].as_array().unwrap();
    let index = rows
        .iter()
        .map(|row| (row["case_id"].as_str().unwrap(), row))
        .collect::<BTreeMap<_, _>>();
    assert_eq!(index.len(), rows.len(), "duplicate original case IDs");
    index
}

fn strings(value: &Value) -> Vec<String> {
    value
        .as_array()
        .unwrap()
        .iter()
        .map(|v| v.as_str().unwrap().to_owned())
        .collect()
}

fn owners(row: &Value) -> Vec<String> {
    strings(&row["required_slices"])
}

fn historical_overlap(row: &Value) -> bool {
    row["parent_membership"]
        .as_array()
        .unwrap()
        .iter()
        .any(|p| p["parent"] == "H2.6c")
}

/// Preserve the pinned 107-file named-library digest, then include the default
/// lib.d.ts wrapper used by the observer's ES5 programs. Both sets use original
/// bytes; there is no installed TypeScript or global host fallback.
fn libraries() -> BTreeMap<String, Vec<u8>> {
    let mut files = BTreeMap::new();
    for entry in std::fs::read_dir(workspace().join("vendor/typescript-6.0.3/lib")).unwrap() {
        let entry = entry.unwrap();
        let name = entry.file_name().into_string().unwrap();
        // Match /^lib\..*\.d\.ts$/ without allowing the prefix and suffix
        // to overlap, as they do in "lib.d.ts".
        if name
            .strip_prefix("lib.")
            .is_some_and(|rest| rest.ends_with(".d.ts"))
        {
            files.insert(name, std::fs::read(entry.path()).unwrap());
        }
    }
    assert_eq!(files.len(), 107);
    let mut hash = Sha256::new();
    for (name, bytes) in &files {
        hash.update(name.as_bytes());
        hash.update([0]);
        hash.update(bytes);
        hash.update([0]);
    }
    assert_eq!(
        format!("{:x}", hash.finalize()),
        "9bb5d7e6912946bf4ed42015a9549d5c61f536bdebb0e1f72e3200235c569b22"
    );
    // The frozen observer permits this wrapper under its library-root fallback;
    // 23 original observations (21 D-only) actually load it. Excluding it from
    // the digest must not remove it from the Program's available library inputs.
    let default_wrapper =
        std::fs::read(workspace().join("vendor/typescript-6.0.3/lib/lib.d.ts")).unwrap();
    assert_eq!(
        digest(&default_wrapper),
        "0e6477e5049e579cc5de741a70ac91235252edc0468b2e569f22de9db3357786"
    );
    assert!(files
        .insert("lib.d.ts".to_owned(), default_wrapper)
        .is_none());
    assert_eq!(files.len(), 108);
    files
}

/// The TS observer's directory overlay canonicalizes directory spellings.
/// MemoryCompilerHost deliberately retains raw keys and uses native parent paths:
/// on POSIX, A:/file.ts creates parent A:, and /a/src/file.ts creates /a/src.
/// Adapt only directory existence; preserve bytes, file identity, enumeration,
/// realpath, original roots and every compiler option.
struct OriginalCorpusHost(MemoryCompilerHost);

impl CompilerHost for OriginalCorpusHost {
    fn current_directory_js(&self) -> Result<tsc_diagnostics::JsString, tsc_host::HostError> {
        self.0.current_directory_js()
    }
    fn read_file_js(
        &self,
        path: tsc_diagnostics::JsStr<'_>,
    ) -> Result<Option<Vec<u8>>, tsc_host::HostError> {
        self.0.read_file_js(path)
    }
    fn file_exists_js(
        &self,
        path: tsc_diagnostics::JsStr<'_>,
    ) -> Result<bool, tsc_host::HostError> {
        self.0.file_exists_js(path)
    }
    fn read_directory_js(
        &self,
        path: tsc_diagnostics::JsStr<'_>,
    ) -> Result<Vec<tsc_diagnostics::JsString>, tsc_host::HostError> {
        self.0.read_directory_js(path)
    }
    fn get_directories_js(
        &self,
        path: tsc_diagnostics::JsStr<'_>,
    ) -> Result<Vec<tsc_diagnostics::JsString>, tsc_host::HostError> {
        self.0.get_directories_js(path)
    }
    fn realpath_js(
        &self,
        path: tsc_diagnostics::JsStr<'_>,
    ) -> Result<Option<tsc_diagnostics::JsString>, tsc_host::HostError> {
        self.0.realpath_js(path)
    }
    fn directory_exists_js(
        &self,
        path: tsc_diagnostics::JsStr<'_>,
    ) -> Result<bool, tsc_host::HostError> {
        if self.0.directory_exists_js(path)? {
            return Ok(true);
        }
        let mut lookup = path;
        while let Some(prefix) = lookup.strip_suffix("/") {
            lookup = prefix;
        }
        self.0
            .directory_exists_js(if lookup.is_empty() { path } else { lookup })
    }

    fn current_directory(&self) -> Result<PathBuf, tsc_host::HostError> {
        self.0.current_directory()
    }

    fn use_case_sensitive_file_names(&self) -> bool {
        self.0.use_case_sensitive_file_names()
    }

    fn read_file(&self, path: &Path) -> Result<Option<Vec<u8>>, tsc_host::HostError> {
        self.0.read_file(path)
    }

    fn file_exists(&self, path: &Path) -> Result<bool, tsc_host::HostError> {
        self.0.file_exists(path)
    }

    fn directory_exists(&self, path: &Path) -> Result<bool, tsc_host::HostError> {
        if self.0.directory_exists(path)? {
            return Ok(true);
        }
        let lookup = path.to_str().map(|name| name.trim_end_matches('/'));
        match lookup {
            Some(name) if !name.is_empty() => self.0.directory_exists(Path::new(name)),
            _ => self.0.directory_exists(path),
        }
    }

    fn read_directory(&self, path: &Path) -> Result<Vec<PathBuf>, tsc_host::HostError> {
        self.0.read_directory(path)
    }

    fn get_directories(&self, path: &Path) -> Result<Vec<PathBuf>, tsc_host::HostError> {
        self.0.get_directories(path)
    }

    fn realpath(&self, path: &Path) -> Result<Option<PathBuf>, tsc_host::HostError> {
        self.0.realpath(path)
    }
}

/// The observer overlays shared mounts, per-case writes, missing config, then aliases.
/// Retaining that order matters independently of root order and discovery order.
fn memory_host(
    case: &Value,
    input_artifact: &Value,
    libraries: &BTreeMap<String, Vec<u8>>,
) -> OriginalCorpusHost {
    let input = &case["input"];
    assert_eq!(input["route"], "whole-program");
    let mut files = BTreeMap::<String, Vec<u8>>::new();
    let mut add = |file: &Value| {
        files.insert(
            file["path"].as_str().unwrap().to_owned(),
            file["text"].as_str().unwrap().as_bytes().to_vec(),
        );
    };
    if let Some(mount) = input["shared_mount"].as_str() {
        assert_eq!(mount, "projects");
        for file in input_artifact["shared_mounts"][mount].as_array().unwrap() {
            add(file);
        }
    }
    for file in input["files"].as_array().unwrap() {
        add(file);
    }
    if !input["config"].is_null() {
        let config = &input["config"];
        files
            .entry(config["path"].as_str().unwrap().to_owned())
            .or_insert_with(|| config["text"].as_str().unwrap().as_bytes().to_vec());
    }
    for link in input["vfs_symlinks"].as_array().unwrap() {
        let bytes = files[link["target_path"].as_str().unwrap()].clone();
        files.insert(link["link_path"].as_str().unwrap().to_owned(), bytes);
    }
    let mut builder = MemoryCompilerHost::builder(input["current_directory"].as_str().unwrap())
        .case_sensitive(input["use_case_sensitive_file_names"].as_bool().unwrap());
    for (path, bytes) in files {
        // Two originals use drive-rooted TS paths even on this POSIX host.
        // Pass their original spellings to the existing Program path normalizer.
        assert!(
            path.starts_with('/') || path.as_bytes().get(1..3).is_some_and(|p| p == b":/"),
            "original VFS path {path}"
        );
        builder = builder.file(path, bytes);
    }
    for (name, bytes) in libraries {
        builder = builder.file(format!("/lib/{name}"), bytes.clone());
    }
    for link in input["vfs_symlinks"].as_array().unwrap() {
        builder = builder.realpath(
            link["link_path"].as_str().unwrap(),
            link["target_path"].as_str().unwrap(),
        );
    }
    OriginalCorpusHost(builder.build().unwrap())
}

fn projected_options(case: &Value, host: &dyn CompilerHost) -> (CompilerOptions, ProgramOptions) {
    let input = &case["input"];
    // The fixed observer uses createProgram(original roots, parsed options overlaid
    // with effective_options). It does not run tsc's config-program entry or replace
    // those roots with a second config glob. That object spread retains the
    // enumerable configFilePath, but drops the non-enumerable configFile AST.
    let mut program = if input["config"].is_null() {
        ProgramOptions::default()
    } else {
        let config = &input["config"];
        let name = config["path"].as_str().unwrap();
        let plan = parse_config_root_plan(
            &CompilerConfigHost::new(host),
            ConfigRootPlanRequest {
                file_name: name.into(),
                text: config["text"].as_str().unwrap().to_owned(),
                base_path: Path::new(name)
                    .parent()
                    .unwrap()
                    .to_str()
                    .expect("scalar fixture config parent")
                    .into(),
            },
        )
        .unwrap();
        assert!(plan.root_parse_diagnostics().is_empty());
        assert!(
            plan.errors().is_empty(),
            "original parseConfig errors: {:?}",
            plan.errors()
        );
        plan.program_options()
            .clone()
            .with_config_file_path(
                plan.program_options()
                    .config_file_path()
                    .expect("the original TS config parse retains configFilePath")
                    .clone(),
            )
            .with_program_owned_config_option_diagnostics()
    };
    let mut options = CompilerOptions::default();
    for (key, value) in case["effective_options"].as_object().unwrap() {
        match key.as_str() {
            "target" => options.target = Some(value.as_i64().unwrap() as i32),
            "module" => options.module = Some(value.as_i64().unwrap() as i32),
            "moduleResolution" => options.module_resolution = Some(value.as_i64().unwrap() as i32),
            "moduleDetection" => options.module_detection = Some(value.as_i64().unwrap() as i32),
            "newLine" => options.new_line = Some(value.as_i64().unwrap() as i32),
            "allowJs" => options.allow_js = value.as_bool().unwrap(),
            "allowImportingTsExtensions" => {
                options.allow_importing_ts_extensions = Some(value.as_bool().unwrap())
            }
            "allowSyntheticDefaultImports" => {
                options.allow_synthetic_default_imports = Some(value.as_bool().unwrap())
            }
            "allowUnreachableCode" => {
                options.allow_unreachable_code = Some(value.as_bool().unwrap())
            }
            "isolatedModules" => options.isolated_modules = Some(value.as_bool().unwrap()),
            "noEmitHelpers" => options.no_emit_helpers = Some(value.as_bool().unwrap()),
            // EF7 universe rows (emitter-final-universe.json) reach these five
            // options; the 809 originals never did.
            "experimentalDecorators" => options.experimental_decorators = value.as_bool().unwrap(),
            "emitDecoratorMetadata" => {
                options.emit_decorator_metadata = Some(value.as_bool().unwrap())
            }
            "noUnusedLocals" => options.no_unused_locals = Some(value.as_bool().unwrap()),
            "noUnusedParameters" => options.no_unused_parameters = Some(value.as_bool().unwrap()),
            "strictBuiltinIteratorReturn" => {
                options.strict_builtin_iterator_return = Some(value.as_bool().unwrap())
            }
            // EF7 plan-base rows (emitter-final-universe-plan-base.json).
            "allowUnusedLabels" => options.allow_unused_labels = Some(value.as_bool().unwrap()),
            "customConditions" => {
                options.custom_conditions =
                    Some(strings(value).into_iter().map(Into::into).collect())
            }
            "downlevelIteration" => options.downlevel_iteration = Some(value.as_bool().unwrap()),
            "erasableSyntaxOnly" => options.erasable_syntax_only = Some(value.as_bool().unwrap()),
            "exactOptionalPropertyTypes" => {
                options.exact_optional_property_types = Some(value.as_bool().unwrap())
            }
            "importsNotUsedAsValues" => {
                options.imports_not_used_as_values = Some(value.as_i64().unwrap() as i32)
            }
            "libReplacement" => options.lib_replacement = Some(value.as_bool().unwrap()),
            "noCheck" => options.no_check = Some(value.as_bool().unwrap()),
            "noFallthroughCasesInSwitch" => {
                options.no_fallthrough_cases_in_switch = Some(value.as_bool().unwrap())
            }
            "noImplicitOverride" => options.no_implicit_override = Some(value.as_bool().unwrap()),
            "noImplicitReturns" => options.no_implicit_returns = Some(value.as_bool().unwrap()),
            "noImplicitThis" => options.no_implicit_this = Some(value.as_bool().unwrap()),
            "noUncheckedIndexedAccess" => {
                options.no_unchecked_indexed_access = Some(value.as_bool().unwrap())
            }
            "noUncheckedSideEffectImports" => {
                options.no_unchecked_side_effect_imports = Some(value.as_bool().unwrap())
            }
            "out" => options.out = Some(value.as_str().unwrap().into()),
            "preserveValueImports" => {
                options.preserve_value_imports = Some(value.as_bool().unwrap())
            }
            "resolvePackageJsonExports" => {
                options.resolve_package_json_exports = Some(value.as_bool().unwrap())
            }
            "resolvePackageJsonImports" => {
                options.resolve_package_json_imports = Some(value.as_bool().unwrap())
            }
            "stableTypeOrdering" => options.stable_type_ordering = Some(value.as_bool().unwrap()),
            "pretty" => {
                // Console-presentation flag of the frozen `@pretty` directive;
                // the observer records diagnostic objects, not rendered text.
                assert!(value.is_boolean());
            }
            "rewriteRelativeImportExtensions" => {
                options.rewrite_relative_import_extensions = Some(value.as_bool().unwrap())
            }
            "skipLibCheck" => options.skip_lib_check = Some(value.as_bool().unwrap()),
            "useUnknownInCatchVariables" => {
                options.use_unknown_in_catch_variables = Some(value.as_bool().unwrap())
            }
            "verbatimModuleSyntax" => {
                options.verbatim_module_syntax = Some(value.as_bool().unwrap())
            }
            "jsx" => options.jsx = Some(value.as_i64().unwrap() as i32),
            "maxNodeModuleJsDepth" => {
                options.max_node_module_js_depth = Some(value.as_f64().unwrap().into())
            }
            "moduleSuffixes" => {
                options.module_suffixes = Some(
                    strings(value)
                        .into_iter()
                        .map(tsc_program::ModuleSuffix::value)
                        .collect(),
                )
            }
            "paths" => {
                let mappings = value
                    .as_object()
                    .unwrap()
                    .iter()
                    .map(|(pattern, substitutions)| {
                        tsc_program::PathMapping::new(
                            pattern,
                            strings(substitutions).into_iter().map(Into::into).collect(),
                        )
                    })
                    .collect();
                program = match case["effective_options"]["pathsBasePath"].as_str() {
                    Some(base) => program.with_config_paths(mappings, base),
                    None => program.with_paths(mappings),
                };
            }
            "pathsBasePath" => {
                assert!(case["effective_options"]["paths"].is_object());
                assert_eq!(program.paths_base_path(), value.as_str().map(Into::into));
            }
            "alwaysStrict" => options.always_strict = Some(value.as_bool().unwrap()),
            "checkJs" => options.check_js = Some(value.as_bool().unwrap()),
            "composite" => options.composite = Some(value.as_bool().unwrap()),
            "declaration" => options.declaration = Some(value.as_bool().unwrap()),
            "declarationMap" => options.declaration_map = Some(value.as_bool().unwrap()),
            "emitDeclarationOnly" => options.emit_declaration_only = Some(value.as_bool().unwrap()),
            "esModuleInterop" => options.es_module_interop = Some(value.as_bool().unwrap()),
            "importHelpers" => options.import_helpers = Some(value.as_bool().unwrap()),
            "incremental" => options.incremental = Some(value.as_bool().unwrap()),
            "inlineSourceMap" => options.inline_source_map = Some(value.as_bool().unwrap()),
            "inlineSources" => options.inline_sources = Some(value.as_bool().unwrap()),
            "isolatedDeclarations" => {
                options.isolated_declarations = Some(value.as_bool().unwrap())
            }
            "noEmit" => options.no_emit = Some(value.as_bool().unwrap()),
            "noEmitOnError" => options.no_emit_on_error = Some(value.as_bool().unwrap()),
            "preserveConstEnums" => options.preserve_const_enums = Some(value.as_bool().unwrap()),
            "noErrorTruncation" => options.no_error_truncation = Some(value.as_bool().unwrap()),
            "noImplicitAny" => options.no_implicit_any = Some(value.as_bool().unwrap()),
            "noResolve" => options.no_resolve = Some(value.as_bool().unwrap()),
            "resolveJsonModule" => options.resolve_json_module = Some(value.as_bool().unwrap()),
            "skipDefaultLibCheck" => {
                options.skip_default_lib_check = Some(value.as_bool().unwrap())
            }
            "sourceMap" => options.source_map = Some(value.as_bool().unwrap()),
            "strict" => options.strict = Some(value.as_bool().unwrap()),
            "strictNullChecks" => options.strict_null_checks = Some(value.as_bool().unwrap()),
            "useDefineForClassFields" => {
                options.use_define_for_class_fields = Some(value.as_bool().unwrap())
            }
            "baseUrl" => options.base_url = Some(value.as_str().unwrap().into()),
            "declarationDir" => options.declaration_dir = Some(value.as_str().unwrap().into()),
            "ignoreDeprecations" => {
                options.ignore_deprecations = Some(value.as_str().unwrap().into())
            }
            "mapRoot" => options.map_root = Some(value.as_str().unwrap().into()),
            "outDir" => options.out_dir = Some(value.as_str().unwrap().into()),
            "outFile" => options.out_file = Some(value.as_str().unwrap().into()),
            "rootDir" => options.root_dir = Some(value.as_str().unwrap().into()),
            "sourceRoot" => options.source_root = Some(value.as_str().unwrap().into()),
            "noLib" => program = program.with_no_lib(value.as_bool().unwrap()),
            "types" => {
                program = program.with_types(strings(value).into_iter().map(Into::into).collect())
            }
            "typeRoots" => {
                let cwd = host.current_directory_js().unwrap();
                program = program.with_type_roots(
                    strings(value)
                        .into_iter()
                        .map(|path| {
                            let display = tsc_program::canonical_emit_path(
                                path.as_str().into(),
                                cwd.as_js(),
                                true,
                            );
                            let canonical = tsc_program::canonical_emit_path(
                                path.as_str().into(),
                                cwd.as_js(),
                                host.use_case_sensitive_file_names(),
                            );
                            ProgramPath::from_js_parts(display.as_js(), canonical.as_js()).unwrap()
                        })
                        .collect(),
                );
            }
            "lib" => {
                // TS's serialized program option uses file names; Rust's existing
                // public option contract uses corresponding catalog keys.
                let catalog = LibraryCatalog::typescript_6_0_3("/lib");
                options.lib = Some(
                    strings(value)
                        .into_iter()
                        .map(|name| {
                            let key = name
                                .strip_prefix("lib.")
                                .and_then(|s| s.strip_suffix(".d.ts"))
                                .unwrap()
                                .to_owned();
                            assert_eq!(catalog.option_file_name(&key), Some(name.as_str()));
                            key
                        })
                        .collect(),
                );
            }
            "traceResolution" => {
                // The frozen observer deliberately supplies host.trace() {}.
                // This host-only reporting flag has no CompilerOptions field and
                // contributes neither command status nor diagnostic observations.
                assert_eq!(value, &json!(true));
            }
            other => panic!("unprojected original option {other}"),
        }
    }
    if case["effective_options"].get("allowJs").is_none() {
        options.allow_js = options.check_js == Some(true);
    }
    if let Some(name) = input["default_library_file_name"].as_str() {
        program = program.with_default_library_file_name(name);
    }
    (options, program)
}

fn prepared(case: &Value, host: &dyn CompilerHost) -> Result<PreparedProgram, ProgramLoadError> {
    let (options, program) = projected_options(case, host);
    let roots = strings(&case["input"]["roots"])
        .into_iter()
        .map(PathBuf::from)
        .collect::<Vec<_>>();
    let catalog = LibraryCatalog::typescript_6_0_3("/lib");
    let limits = ProgramLoadLimits::new(256, 2048, 64, 16 * 1024 * 1024, 128 * 1024 * 1024);
    // The CLI's explicit-files route (`execute_explicit_files`): an effective
    // `noEmit` program is the H0 checking program, whose command reports the
    // ordered diagnostic stream with tsc's empty build-info emit result.
    if options.no_emit == Some(true) {
        load_program(host, &roots, options, program, &catalog, limits)
    } else {
        load_emitting_program(host, &roots, options, program, &catalog, limits)
    }
}

fn message(chain: &MessageChain, indent: usize, text: &mut String) {
    if indent != 0 {
        text.push('\n');
        text.push_str(&"  ".repeat(indent));
    }
    text.push_str(chain.text.as_str().expect("scalar frozen diagnostic text"));
    for next in &chain.next {
        message(next, indent + 1, text);
    }
}

fn diagnostics(diagnostics: &[Diagnostic]) -> Value {
    json!(diagnostics.iter().map(|d| {
        let mut text = String::new(); message(&d.message, 0, &mut text);
        let related = (d.related_information_present || !d.related.is_empty()).then(|| d.related.iter().map(|r| {
            let mut text = String::new(); message(&r.message, 0, &mut text);
            json!({"code":r.message.code,"category":format!("{:?}",r.message.category),
                "file":r.file_name.as_ref().map(|value| scalar_observation(value.as_js())),"start":r.start,"length":r.length,"message":text,"related_information":null})
        }).collect::<Vec<_>>());
        json!({"code":d.code(),"category":format!("{:?}",d.category()),"file":d.file_name.as_ref().map(|value| scalar_observation(value.as_js())),
            "start":d.start,"length":d.length,"message":text,"related_information":related})
    }).collect::<Vec<_>>())
}

fn write(index: usize, artifact: &EmitArtifact) -> Value {
    let path = scalar_observation(artifact.path());
    let kind = match artifact.kind() {
        EmitArtifactKind::JavaScript => "javascript",
        EmitArtifactKind::Declaration => "declaration",
        EmitArtifactKind::JavaScriptMap | EmitArtifactKind::DeclarationMap => "source-map",
        EmitArtifactKind::BuildInfo => panic!("BLD1 output escaped D-only comparison"),
    };
    let (keys, position, data_diagnostics) = match artifact.metadata() {
        Some(EmitWriteMetadata::Text(data)) => (
            json!(["sourceMapUrlPos", "diagnostics"]),
            json!(data.source_map_url_position().map(|p| p.value())),
            diagnostics(data.diagnostics()),
        ),
        None => (Value::Null, Value::Null, Value::Null),
        _ => panic!("unexpected original callback metadata"),
    };
    json!({"index":index,"path":path,"kind":kind,
        "callback_utf8_base64":base64::engine::general_purpose::STANDARD.encode(artifact.callback_bytes()),
        "callback_utf8_bytes":artifact.callback_bytes().len(),"write_byte_order_mark":artifact.write_byte_order_mark(),
        "materialized_utf8_base64":base64::engine::general_purpose::STANDARD.encode(artifact.materialized_bytes()),
        "materialized_utf8_bytes":artifact.materialized_bytes().len(),
        // OutputSink::write's Result is the typed equivalent of onError.
        "on_error_callback_present":true,"source_files":artifact.source_files().map(|values| values.iter().map(|value| scalar_observation(value.as_js())).collect::<Vec<_>>()),
        "data_present":artifact.metadata().is_some(),"data_keys":keys,
        "data_source_map_url_pos":position,"data_diagnostics":data_diagnostics,"data_build_info":null})
}

fn observe(case: &Value, host: &dyn CompilerHost, libraries: &BTreeMap<String, Vec<u8>>) -> Value {
    let program =
        prepared(case, host).unwrap_or_else(|error| panic!("load_emitting_program: {error:?}"));
    let mut sources = Vec::new();
    let mut standard_libraries = Vec::new();
    for source in program.source_files() {
        let path = source.path().display();
        let name = path.as_str().expect("scalar frozen source filename");
        // Check actual loaded source bytes independently from its observed order.
        let bytes = host.read_file_js(path).unwrap().unwrap();
        let text = std::str::from_utf8(&bytes)
            .unwrap()
            .strip_prefix('\u{feff}')
            .unwrap_or(std::str::from_utf8(&bytes).unwrap());
        assert_eq!(
            digest(source.text()),
            digest(text),
            "loaded source bytes {name}"
        );
        if let Some(basename) = name
            .strip_prefix("/lib/")
            .filter(|n| libraries.contains_key(*n))
        {
            standard_libraries.push(basename.to_owned());
        } else {
            sources.push(name.to_owned());
        }
    }
    let mut sink = MemoryOutputSink::new();
    let command = ProgramSession::new(program)
        .emit_command_for_harness(&mut sink)
        .unwrap_or_else(|error| {
            let writes = sink
                .writes()
                .iter()
                .map(|a| (scalar_observation(a.path()), digest(a.callback_bytes())))
                .collect::<Vec<_>>();
            panic!(
                "ordinary Program/command: {error:?}; partial callback paths/SHA256: {writes:?}"
            );
        });
    let outcome = command.emit();
    let activity = outcome.h2_activity();
    for (slice, requested) in [
        (
            tsc_emitter::H2RuntimeSlice::H2_7d,
            case["effective_options"]["outFile"]
                .as_str()
                .is_some_and(|path| !path.is_empty()),
        ),
        (
            tsc_emitter::H2RuntimeSlice::H2_7e,
            case["effective_options"]["declarationMap"] == true,
        ),
    ] {
        assert_eq!(
            activity.runtime_slice(slice),
            u64::from(requested),
            "{}: {} request",
            case["case_id"],
            slice.name()
        );
    }
    for slice in tsc_emitter::H2RuntimeSlice::ALL {
        if slice == tsc_emitter::H2RuntimeSlice::H2_7a || slice > tsc_emitter::H2RuntimeSlice::H2_7e
        {
            assert_eq!(
                activity.runtime_slice(slice),
                0,
                "{}: inactive {}",
                case["case_id"],
                slice.name()
            );
        }
    }
    let maps = outcome.source_maps().map(|maps| {
        maps.iter().map(|map| json!({
        "input_source_file_names":map.input_source_files().iter().map(|value| scalar_observation(value.as_js())).collect::<Vec<_>>(),"source_map_json":map.canonical_json()
    })).collect::<Vec<_>>()
    });
    json!({"program_source_order":sources,"standard_libraries":standard_libraries,
        "writes":sink.writes().iter().enumerate().map(|(i,a)| write(i,a)).collect::<Vec<_>>(),
        "reported_diagnostics":diagnostics(command.diagnostics()),"emit_refused":outcome.emit_skipped(),
        "emit_result":{"emit_skipped":outcome.emit_skipped(),"diagnostics":diagnostics(outcome.diagnostics()),
            "emitted_files":outcome.emitted_files().map(|values| values.iter().map(|value| scalar_observation(value.as_js())).collect::<Vec<_>>()),"source_maps":maps},
        // Real cli::emit_command_status producer; no test-side status/exit inference.
        "status_writes":command.status_writes().iter().map(|value| scalar_observation(value.as_js())).collect::<Vec<_>>(),"exit_code":command.exit_code()})
}

fn short(value: &Value) -> String {
    let text = value.to_string();
    let mut result = text.chars().take(160).collect::<String>();
    if text.chars().count() > 160 {
        result.push_str("...");
    }
    result
}

fn difference(actual: &Value, expected: &Value, path: &str) -> Option<String> {
    if actual == expected {
        return None;
    }
    match (actual, expected) {
        (Value::Object(a), Value::Object(e)) => {
            if a.keys().ne(e.keys()) {
                return Some(format!(
                    "{path}: object keys {:?} != {:?}",
                    a.keys(),
                    e.keys()
                ));
            }
            for (key, value) in e {
                if let Some(diff) = difference(&a[key], value, &format!("{path}.{key}")) {
                    return Some(diff);
                }
            }
        }
        (Value::Array(a), Value::Array(e)) => {
            if a.len() != e.len() {
                return Some(format!("{path}: length {} != {}", a.len(), e.len()));
            }
            for (index, (a, e)) in a.iter().zip(e).enumerate() {
                if let Some(diff) = difference(a, e, &format!("{path}[{index}]")) {
                    return Some(diff);
                }
            }
        }
        (Value::String(a), Value::String(e)) if path.ends_with("_base64") => {
            let decode = |s: &str| base64::engine::general_purpose::STANDARD.decode(s).unwrap();
            let (a, e) = (decode(a), decode(e));
            let offset = a
                .iter()
                .zip(&e)
                .position(|(a, e)| a != e)
                .unwrap_or(a.len().min(e.len()));
            return Some(format!(
                "{path}: UTF-8 byte {offset}, actual length {}, expected length {}",
                a.len(),
                e.len()
            ));
        }
        _ => {}
    }
    Some(format!(
        "{path}: actual {} != expected {}",
        short(actual),
        short(expected)
    ))
}

fn assert_complete(actual: &Value, expected: &Value) {
    assert_eq!(
        actual.as_object().unwrap().keys().collect::<Vec<_>>(),
        expected.as_object().unwrap().keys().collect::<Vec<_>>()
    );
    let differences = expected
        .as_object()
        .unwrap()
        .iter()
        .filter_map(|(field, expected)| difference(&actual[field], expected, field))
        .collect::<Vec<_>>();
    assert!(differences.is_empty(), "{}", differences.join("; "));
}

fn panic_text(error: &(dyn std::any::Any + Send)) -> String {
    error
        .downcast_ref::<String>()
        .cloned()
        .or_else(|| error.downcast_ref::<&str>().map(|s| (*s).to_owned()))
        .unwrap_or_else(|| "non-string panic".to_owned())
}

fn assert_original_source(row: &Value) {
    let source = &row["source"];
    let path = workspace()
        .join("ts-tests/tests/cases")
        .join(row["suite"].as_str().unwrap())
        .join(source["path"].as_str().unwrap());
    let bytes = std::fs::read(&path).unwrap();
    assert_eq!(json!(bytes.len()), source["bytes"], "{path:?}");
    assert_eq!(json!(digest(&bytes)), source["sha256"], "{path:?}");
}

/// Preserve the 32 later-owner intersections without treating facet comparisons or
/// a present typed error as a complete TS tuple. Only noEmit's loader gate is
/// independently established here; the other entrances are recorded for review.
fn assert_reference(
    row: &Value,
    case: &Value,
    artifact: &Value,
    libraries: &BTreeMap<String, Vec<u8>>,
) {
    let options = &case["effective_options"];
    let owner = owners(row);
    let gate = match owner.as_slice() {
        [d, a] if d == "H2.7d" && a == "H2.8a" => {
            assert!(options.get("rootDir").is_some() || options.get("outDir").is_some());
            "ordinary emitter validate_emit_request: rootDir/outDir"
        }
        [d, b] if d == "H2.7d" && b == "H2.8b" => {
            if options["incremental"] == true || options["composite"] == true {
                "ordinary emitter validate_emit_options: incremental/composite; build runtime BLD1"
            } else if options["importHelpers"] == true {
                "bundle importHelpers: post-outFile production refusal remains to be established"
            } else {
                assert_eq!(case["input"]["use_case_sensitive_file_names"], false);
                "case-insensitive bundle host: post-outFile production refusal remains to be established"
            }
        }
        [d, n] if d == "H2.7d" && n == "H2.9" => {
            if options["noEmit"] == true {
                let host = memory_host(case, artifact, libraries);
                for _ in 0..2 {
                    let error = prepared(case, &host).unwrap_err();
                    assert!(
                        matches!(error, ProgramLoadError::InvalidInput {
                        operation: ProgramLoadOperation::ValidateOptions, path: None, js_path: None, ref detail,
                    } if detail == "emitting program rejects effective compilerOptions.noEmit=true"),
                        "{error:?}"
                    );
                }
                "load_emitting_program ValidateOptions: noEmit=true, verified twice"
            } else {
                assert_eq!(
                    row["case_id"],
                    "typescript-6.0.3/compiler/jsFileCompilationTypeAssertions.ts#default"
                );
                assert_eq!(
                    row["source_facts"]["parse_diagnostic_units"],
                    json!([{"path":"/src/a.js","codes":[17008,1005]}])
                );
                "ordinary transform ParseDiagnosticsDeferred/H2.9; not a successful emit"
            }
        }
        _ => panic!("unexpected D reference owners {owner:?}"),
    };
    eprintln!("H2.7d original REFERENCE {}: {gate}", row["case_id"]);
}

pub(super) fn assert_original_corpus(workspace_root: &Path) -> BTreeSet<String> {
    assert_eq!(
        workspace_root.canonicalize().unwrap(),
        workspace().canonicalize().unwrap(),
        "H2.7d caller must select the compiled workspace",
    );
    let census_artifact = frozen(CENSUS);
    let input_artifact = frozen(INPUTS);
    let observation_artifact = frozen(ORACLE);
    assert_eq!(observation_artifact["repetitions"], 2);
    // Check the observer and all its input dependencies, without re-running TS
    // or requiring historical qualification files to be rewritten for this test.
    for pin in observation_artifact["inputs"]
        .as_array()
        .unwrap()
        .iter()
        .chain(std::iter::once(&observation_artifact["generator"]))
    {
        let path = pin["path"].as_str().unwrap();
        assert_eq!(
            json!(digest(std::fs::read(workspace().join(path)).unwrap())),
            pin["sha256"],
            "{path}"
        );
    }
    let census = indexed(&census_artifact);
    let inputs = indexed(&input_artifact);
    let observations = indexed(&observation_artifact);
    assert_eq!(census.len(), 325);
    assert_eq!(inputs.len(), 325);
    assert_eq!(observations.len(), 323);
    assert!(census.keys().eq(inputs.keys()));
    assert_eq!(
        input_artifact["shared_mounts"]["projects"]
            .as_array()
            .unwrap()
            .len(),
        233
    );
    let libraries = libraries();
    let mut counts = BTreeMap::<String, usize>::new();
    let mut overlaps = BTreeMap::<String, usize>::new();
    for (id, row) in &census {
        let input = inputs[id];
        assert_eq!(row["source"], input["source"]);
        assert_eq!(row["suite"], input["suite"]);
        assert_eq!(row["runtime_admitted"], false);
        assert_eq!(row["disposition"], "candidate-only");
        let group = owners(row).join(",");
        *counts.entry(group.clone()).or_default() += 1;
        *overlaps.entry(group).or_default() += usize::from(historical_overlap(row));
        if input["input"]["route"] == "transpile-api" {
            assert_eq!(owners(row), ["H2.7e", "H2.8c"]);
            assert!(!observations.contains_key(id));
            assert_eq!(input["input"]["units"].as_array().unwrap().len(), 5);
            continue;
        }
        let reference = observations[id];
        // The SHA-pinned input file fixes every row byte, including original JSON
        // member order used by JS's JSON.stringify hash. Join that row identity;
        // reserializing serde_json's sorted object map would hash different bytes.
        assert_eq!(row["input_sha256"], reference["input_sha256"]);
        assert_eq!(row["required_slices"], reference["required_slices"]);
        assert_eq!(reference["repetitions"], 2);
        assert_eq!(reference["disposition"], "typescript-reference-only");
        if owners(row).iter().any(|owner| owner == "H2.7d") {
            assert_original_source(row);
        }
    }
    assert_eq!(
        json!(counts),
        json!({"H2.7d":280,"H2.7d,H2.7e":3,"H2.7d,H2.8a":23,
        "H2.7d,H2.8b":5,"H2.7d,H2.9":4,"H2.7e":8,"H2.7e,H2.8c":2})
    );
    assert_eq!(overlaps["H2.7d"], 154);
    assert_eq!(overlaps.values().sum::<usize>(), 177);
    let mut failures = Vec::new();
    let mut compared_ids = BTreeSet::new();
    let mut compared = 0;
    let mut exact = 0;
    let mut exact_overlap = 0;
    let mut references = 0;
    for (id, row) in &census {
        if !owners(row).iter().any(|owner| owner == "H2.7d") {
            continue;
        }
        let case = inputs[id];
        if !matches!(owners(row).as_slice(), [d] if d == "H2.7d")
            && owners(row) != ["H2.7d", "H2.7e"]
        {
            references += 1;
            assert_reference(row, case, &input_artifact, &libraries);
            continue;
        }
        compared += 1;
        let expected = &observations[id]["typescript_observation"];
        let before = failures.len();
        // Catch each repetition independently: one failure cannot skip its second
        // fresh Program or hide later cases. No checker/library-prefix cache reuse.
        for repetition in 0..2 {
            let result = std::panic::catch_unwind(|| {
                let host = memory_host(case, &input_artifact, &libraries);
                let actual = observe(case, &host, &libraries);
                // Optional failure artifacts preserve the complete observations;
                // selecting an artifact directory never filters the corpus.
                if actual != *expected {
                    if let Some(directory) = std::env::var_os("TSC_RS_H2_7D_FAILURE_DIR") {
                        let directory = PathBuf::from(directory);
                        std::fs::create_dir_all(&directory).unwrap();
                        let record = json!({
                            "case_id": id,
                            "repetition": repetition + 1,
                            "actual": actual,
                            "expected": expected,
                        });
                        std::fs::write(
                            directory.join(format!("{}-{}.json", digest(id), repetition + 1)),
                            serde_json::to_vec_pretty(&record).unwrap(),
                        )
                        .unwrap();
                    }
                }
                assert_complete(&actual, expected);
            });
            if let Err(error) = result {
                failures.push(format!(
                    "{id} repetition {}: {}",
                    repetition + 1,
                    panic_text(error.as_ref())
                ));
            }
        }
        if failures.len() == before {
            assert!(compared_ids.insert((*id).to_owned()));
            exact += 1;
            exact_overlap += usize::from(historical_overlap(row));
            eprintln!("H2.7d original EXACT x2 {id}");
        }
    }
    assert_eq!(compared, 283);
    assert_eq!(references, 32);
    // Distinct original IDs, never band totals added together. These are local
    // comparison results only; runtime activity/admission remains separately owned.
    eprintln!("H2.7d original: compared={compared}, exact={exact}, references={references}, H2.6c exact overlap={exact_overlap}, exact IDs outside H2.6c={}; union=325, input-preserving repetitions=2", exact - exact_overlap);
    assert!(
        failures.is_empty(),
        "{} failed repetitions:\n{}",
        failures.len(),
        failures.join("\n")
    );
    assert_eq!(exact, 283);
    assert_eq!(exact_overlap, 155);
    assert_eq!(exact - exact_overlap, 128);
    assert_eq!(compared_ids.len(), 283);
    compared_ids
}

/// The H2.8a entry independently executes the original output-directory
/// intersections; the D283 qualification and its membership remain frozen.
#[allow(dead_code)] // This shared module is also compiled by the D283 entry.
pub(super) fn assert_output_directory_references(workspace_root: &Path) -> BTreeSet<String> {
    assert_eq!(
        workspace_root.canonicalize().unwrap(),
        workspace().canonicalize().unwrap()
    );
    let census_artifact = frozen(CENSUS);
    let input_artifact = frozen(INPUTS);
    let observation_artifact = frozen(ORACLE);
    let current: Value = serde_json::from_slice(
        &std::fs::read(workspace().join("ratchets/h2-8a-output-directory-corpus.v1.json")).unwrap(),
    )
    .unwrap();
    assert_eq!(current["kind"], "h2-8a-output-directory-corpus");
    assert_eq!(current["typescript"], "6.0.3");
    assert_eq!(current["repetitions"], 2);
    for pin in current["inputs"]
        .as_array()
        .unwrap()
        .iter()
        .chain([&current["generator"]])
    {
        assert_eq!(
            json!(digest(
                std::fs::read(workspace().join(pin["path"].as_str().unwrap())).unwrap()
            )),
            pin["sha256"]
        );
    }
    let census = indexed(&census_artifact);
    let inputs = indexed(&input_artifact);
    let original = indexed(&observation_artifact);
    let fresh = indexed(&current);
    let selected = census
        .iter()
        .filter(|(_, row)| owners(row) == ["H2.7d", "H2.8a"])
        .map(|(id, _)| *id)
        .collect::<BTreeSet<_>>();
    assert_eq!(selected.len(), 23);
    assert_eq!(selected, fresh.keys().copied().collect());
    let libraries = libraries();
    let mut exact = BTreeSet::new();
    let mut failures = Vec::new();
    for id in selected {
        assert_original_source(census[id]);
        assert_eq!(fresh[id]["input_sha256"], original[id]["input_sha256"]);
        assert_eq!(
            fresh[id]["typescript_observation"],
            original[id]["typescript_observation"]
        );
        let before = failures.len();
        for repetition in 0..2 {
            let compared = std::panic::catch_unwind(|| {
                let host = memory_host(inputs[id], &input_artifact, &libraries);
                let actual = observe(inputs[id], &host, &libraries);
                let expected = &fresh[id]["typescript_observation"];
                if actual != *expected {
                    if let Some(directory) = std::env::var_os("TSC_RS_H2_8A_FAILURE_DIR") {
                        let directory = PathBuf::from(directory);
                        std::fs::create_dir_all(&directory).unwrap();
                        std::fs::write(
                            directory.join(format!("{}-{repetition}.json", digest(id))),
                            serde_json::to_vec_pretty(
                                &json!({"case_id":id,"repetition":repetition,
                                "actual":actual,"expected":expected}),
                            )
                            .unwrap(),
                        )
                        .unwrap();
                    }
                }
                assert_complete(&actual, expected);
            });
            if let Err(error) = compared {
                failures.push(format!(
                    "{id} repetition {repetition}: {}",
                    panic_text(error.as_ref())
                ));
            }
        }
        if failures.len() == before {
            exact.insert(id.to_owned());
            eprintln!("H2.8a original directory EXACT x2 {id}");
        }
    }
    assert!(
        failures.is_empty(),
        "{} directory corpus failures:\n{}",
        failures.len(),
        failures.join("\n")
    );
    assert_eq!(exact.len(), 23);
    exact
}

/// Fresh original output inputs through the existing complete command comparator.
/// Membership is frozen independently of Rust success; every eligible row runs
/// twice and every mismatch remains a failure.
#[allow(dead_code)] // Also imported by the D/E runner until H2.8a hosted integration.
pub(super) fn assert_output_matrix_candidates(workspace_root: &Path) -> BTreeSet<String> {
    assert_output_matrix_cases(workspace_root, None)
}

#[allow(dead_code)] // Focused original-input projections share the complete comparator.
pub(super) fn assert_output_matrix_projection(
    workspace_root: &Path,
    selected: &[&str],
) -> BTreeSet<String> {
    let ids = selected.iter().copied().collect::<BTreeSet<_>>();
    assert_eq!(ids.len(), selected.len(), "duplicate focused input");
    assert_output_matrix_cases(workspace_root, Some(&ids))
}

/// The parse census used the qualified emit loader and therefore refused these
/// two noEmit commands. Exercise the existing ordinary checking-command route
/// against the original TS tuples without changing that historical census.
#[allow(dead_code)] // Only emitter_final_batch selects this supplemental entry.
pub(super) fn assert_no_emit_census_commands(workspace_root: &Path) {
    assert_eq!(
        workspace_root.canonicalize().unwrap(),
        workspace().canonicalize().unwrap()
    );
    let read = |name: &str| -> Value {
        serde_json::from_slice(&std::fs::read(workspace().join(name)).unwrap()).unwrap()
    };
    let candidates = read("ratchets/h2-8a-candidates.v1.json");
    let inputs = read("ratchets/h2-8a-candidate-inputs.v1.json");
    let oracle = read("ratchets/h2-8a-observations.v1.json");
    for artifact in [&candidates, &inputs, &oracle] {
        assert_eq!(artifact["typescript"], "6.0.3");
        assert_eq!(artifact["source_commit"], SOURCE_COMMIT);
        assert_eq!(artifact["cases"].as_array().unwrap().len(), 809);
    }
    for artifact in [&candidates, &oracle] {
        for pin in artifact["inputs"]
            .as_array()
            .unwrap()
            .iter()
            .chain([&artifact["generator"]])
        {
            assert_eq!(
                json!(digest(
                    std::fs::read(workspace().join(pin["path"].as_str().unwrap())).unwrap()
                )),
                pin["sha256"]
            );
        }
    }
    assert_eq!(oracle["repetitions"], 2);
    let candidate_rows = indexed(&candidates);
    let input_rows = indexed(&inputs);
    let oracle_rows = indexed(&oracle);
    let libraries = libraries();
    for value in ["false", "true"] {
        let id = format!("typescript-6.0.3/conformance/moduleResolution/bundler/bundlerImportTsExtensions.ts#allowimportingtsextensions%3D{value}%2Cnoemit%3Dtrue");
        let candidate = candidate_rows[id.as_str()];
        let input = input_rows[id.as_str()];
        let reference = oracle_rows[id.as_str()];
        assert_original_source(candidate);
        assert_eq!(
            candidate["input_sha256"],
            digest(serde_json::to_vec(input).unwrap())
        );
        assert_eq!(reference["input_sha256"], candidate["input_sha256"]);
        assert_eq!(reference["required_slices"], candidate["required_slices"]);
        assert_eq!(owners(candidate), ["H2.8a", "H2.9"]);
        assert_eq!(reference["repetitions"], 2);
        assert_eq!(input["effective_options"]["noEmit"], true);
        let expected = &reference["typescript_observation"];
        assert_eq!(expected["writes"], json!([]));
        for repetition in 0..2 {
            let host = memory_host(input, &inputs, &libraries);
            let actual = observe(input, &host, &libraries);
            if let Some(directory) = std::env::var_os("TSC_RS_EMITTER_FINAL_CAPTURE_DIR") {
                let directory = PathBuf::from(directory);
                std::fs::create_dir_all(&directory).unwrap();
                std::fs::write(
                    directory.join(format!("{}-{repetition}.json", digest(&id))),
                    serde_json::to_vec_pretty(&json!({"case_id":id,"repetition":repetition,"actual":actual,"expected":expected})).unwrap(),
                ).unwrap();
            }
            assert_complete(&actual, expected);
        }
        eprintln!("noEmit census command EXACT x2 {id}");
    }
}

fn assert_output_matrix_cases(
    workspace_root: &Path,
    selected: Option<&BTreeSet<&str>>,
) -> BTreeSet<String> {
    assert_eq!(
        workspace_root.canonicalize().unwrap(),
        workspace().canonicalize().unwrap()
    );
    let read = |name: &str| -> Value {
        serde_json::from_slice(&std::fs::read(workspace().join(name)).unwrap()).unwrap()
    };
    let census_artifact = read("ratchets/h2-8a-candidates.v1.json");
    let input_artifact = read("ratchets/h2-8a-candidate-inputs.v1.json");
    let oracle_artifact = read("ratchets/h2-8a-observations.v1.json");
    for artifact in [&census_artifact, &input_artifact, &oracle_artifact] {
        assert_eq!(artifact["typescript"], "6.0.3");
        assert_eq!(artifact["source_commit"], SOURCE_COMMIT);
        assert_eq!(artifact["cases"].as_array().unwrap().len(), 809);
    }
    for artifact in [&census_artifact, &oracle_artifact] {
        for pin in artifact["inputs"]
            .as_array()
            .unwrap()
            .iter()
            .chain([&artifact["generator"]])
        {
            assert_eq!(
                json!(digest(
                    std::fs::read(workspace().join(pin["path"].as_str().unwrap())).unwrap()
                )),
                pin["sha256"]
            );
        }
    }
    assert_eq!(oracle_artifact["repetitions"], 2);
    let census = indexed(&census_artifact);
    let inputs = indexed(&input_artifact);
    let oracle = indexed(&oracle_artifact);
    assert_eq!(
        census.keys().collect::<Vec<_>>(),
        inputs.keys().collect::<Vec<_>>()
    );
    assert_eq!(
        census.keys().collect::<Vec<_>>(),
        oracle.keys().collect::<Vec<_>>()
    );
    let libraries = libraries();
    let mut exact = BTreeSet::new();
    let mut failures = Vec::new();
    let mut eligible = 0;
    for (id, candidate) in &census {
        assert_original_source(candidate);
        assert_eq!(
            candidate["input_sha256"],
            digest(serde_json::to_vec(inputs[id]).unwrap())
        );
        assert_eq!(oracle[id]["input_sha256"], candidate["input_sha256"]);
        assert_eq!(oracle[id]["required_slices"], candidate["required_slices"]);
        assert_eq!(oracle[id]["repetitions"], 2);
        assert_eq!(candidate["disposition"], "candidate-only");
        assert_eq!(candidate["runtime_admitted"], false);
        if owners(candidate) != ["H2.8a"] {
            continue;
        }
        eligible += 1;
        if selected.is_some_and(|ids| !ids.contains(id)) {
            continue;
        }
        let before = failures.len();
        for repetition in 0..2 {
            let compared = std::panic::catch_unwind(|| {
                let host = memory_host(inputs[id], &input_artifact, &libraries);
                let actual = observe(inputs[id], &host, &libraries);
                let expected = &oracle[id]["typescript_observation"];
                if actual != *expected {
                    if let Some(directory) = std::env::var_os("TSC_RS_H2_8A_FAILURE_DIR") {
                        let directory = PathBuf::from(directory);
                        std::fs::create_dir_all(&directory).unwrap();
                        std::fs::write(directory.join(format!("{}-{repetition}.json", digest(id))),
                            serde_json::to_vec_pretty(&json!({"case_id":id,"repetition":repetition,"actual":actual,"expected":expected})).unwrap()).unwrap();
                    }
                }
                assert_complete(&actual, expected);
            });
            if let Err(error) = compared {
                failures.push(format!(
                    "{id} repetition {repetition}: {}",
                    panic_text(error.as_ref())
                ));
            }
        }
        if failures.len() == before {
            exact.insert((*id).to_owned());
            eprintln!("H2.8a output matrix EXACT x2 {id}");
        }
    }
    assert_eq!(eligible, 769);
    assert!(
        failures.is_empty(),
        "{} output matrix failures:\n{}",
        failures.len(),
        failures.join("\n")
    );
    assert_eq!(exact.len(), selected.map_or(eligible, BTreeSet::len));
    if let Some(selected) = selected {
        assert_eq!(
            exact.iter().map(String::as_str).collect::<BTreeSet<_>>(),
            *selected
        );
    }
    exact
}

// This legacy JSON schema owns scalar strings. Reject unexpected lone units
// explicitly at the observation boundary instead of changing their identity.
fn scalar_observation(value: tsc_diagnostics::JsStr<'_>) -> String {
    value
        .as_str()
        .expect("non-scalar JS value cannot match this scalar frozen observation")
        .to_owned()
}

/// One EF7 universe row's replay result (the fixture row keeps the frozen
/// TypeScript tuple; the comparison is the same complete-command comparator
/// as the 769 original candidates).
#[allow(dead_code)] // Only the emitter-final universe test includes this entry.
#[derive(Debug, Default)]
pub(super) struct UniverseReplay {
    pub(super) exact: BTreeSet<String>,
    pub(super) diverging: BTreeMap<String, Value>,
    pub(super) all_ids: BTreeSet<String>,
}

/// Replay every case of a universe fixture (`crates/compiler/tests/fixtures/<name>`,
/// the `emitter-final-universe` schema: original candidate-input rows plus their
/// fresh `typescript_observation`) twice through the ordinary Program command,
/// exactly like `assert_output_matrix_cases`. Nothing is asserted here beyond the
/// fixture pins and the two-repetition contract; the caller owns the KNOWN /
/// retire policy. Mismatches are written to `TSC_RS_EMITTER_FINAL_FAILURE_DIR`
/// when that directory is set.
#[allow(dead_code)] // Only the emitter-final universe test includes this entry.
pub(super) fn replay_universe_fixture(
    workspace_root: &Path,
    name: &str,
    select: impl Fn(usize, &str) -> bool,
) -> UniverseReplay {
    assert_eq!(
        workspace_root.canonicalize().unwrap(),
        workspace().canonicalize().unwrap()
    );
    // Plain JSON, or zstd-compressed JSON (`<name>.zst`) for the multi-megabyte
    // plan-base set; the pins refer to the decoded bytes' inputs either way.
    let path = workspace()
        .join("crates/compiler/tests/fixtures")
        .join(name);
    let bytes = if path.is_file() {
        std::fs::read(&path).unwrap()
    } else {
        let compressed = path.with_file_name(format!("{name}.zst"));
        zstd::stream::decode_all(std::fs::read(&compressed).unwrap().as_slice()).unwrap()
    };
    let artifact: Value = serde_json::from_slice(&bytes).unwrap();
    assert_eq!(artifact["kind"], "emitter-final-universe");
    assert_eq!(artifact["typescript"], "6.0.3");
    assert_eq!(artifact["repetitions"], 2);
    for pin in artifact["inputs"]
        .as_array()
        .unwrap()
        .iter()
        .chain([&artifact["generator"]])
    {
        assert_eq!(
            json!(digest(
                std::fs::read(workspace().join(pin["path"].as_str().unwrap())).unwrap()
            )),
            pin["sha256"],
            "{}",
            pin["path"]
        );
    }
    let cases = indexed(&artifact);
    let libraries = libraries();
    let mut report = UniverseReplay {
        all_ids: cases.keys().map(|id| (*id).to_owned()).collect(),
        ..UniverseReplay::default()
    };
    for (index, (id, case)) in cases.iter().enumerate() {
        if !select(index, id) {
            continue;
        }
        assert_original_source(case);
        assert_eq!(case["repetitions"], 2);
        assert_eq!(case["input"]["route"], "whole-program");
        let expected = &case["typescript_observation"];
        let mut outcomes = Vec::new();
        for repetition in 0..2 {
            let observed = std::panic::catch_unwind(|| {
                let host = memory_host(case, &artifact, &libraries);
                observe(case, &host, &libraries)
            });
            let outcome = match observed {
                Ok(actual) => json!({"kind": "complete", "observation": actual}),
                Err(error) => json!({"kind": "failure", "message": panic_text(error.as_ref())}),
            };
            if outcome["observation"] != *expected {
                if let Some(directory) = std::env::var_os("TSC_RS_EMITTER_FINAL_FAILURE_DIR") {
                    let directory = PathBuf::from(directory);
                    std::fs::create_dir_all(&directory).unwrap();
                    std::fs::write(
                        directory.join(format!("{}-{repetition}.json", digest(id))),
                        serde_json::to_vec_pretty(&json!({"case_id": id,
                            "repetition": repetition, "native": outcome, "expected": expected}))
                        .unwrap(),
                    )
                    .unwrap();
                }
            }
            outcomes.push(outcome);
        }
        assert_eq!(
            outcomes[0], outcomes[1],
            "{id}: native observations must repeat exactly"
        );
        let outcome = outcomes.pop().unwrap();
        if outcome["kind"] == "complete" && outcome["observation"] == *expected {
            report.exact.insert((*id).to_owned());
            eprintln!("emitter-final universe EXACT x2 {id}");
        } else {
            let detail = if outcome["kind"] == "failure" {
                outcome["message"].as_str().unwrap().to_owned()
            } else {
                difference(&outcome["observation"], expected, "command").unwrap()
            };
            eprintln!("emitter-final universe DIVERGING {id}: {detail}");
            report.diverging.insert((*id).to_owned(), outcome);
        }
    }
    report
}
