use tsc_emitter::*;
use tsc_syntax::{parse_source_file,NodeData};
fn main(){
 for (name,flag) in [("none",EmitFlags::NONE),("no-leading",EmitFlags::NO_LEADING_COMMENTS),("no-trailing",EmitFlags::NO_TRAILING_COMMENTS),("no-nested",EmitFlags::NO_NESTED_COMMENTS),("no-own",EmitFlags::NO_COMMENTS)] {
 let parsed=parse_source_file("/a.ts","function f() {\n// head\n\nx();\n// tail\n}\n",Default::default(),None);
 let mut arena=TransformArena::new();let source=arena.add_source(&parsed,None);let root=arena.root(source).unwrap();
 let NodeData::SourceFile(data)=&arena.node(root).unwrap().data else{panic!()};let array=arena.node_array_ref(source,data.statements.unwrap()).unwrap();let id=arena.node_array(array).unwrap().nodes[0];let function=arena.node_ref(source,id).unwrap();
 let NodeData::FunctionDeclaration(data)=&arena.node(function).unwrap().data else{panic!()};let body=arena.node_ref(source,data.body.unwrap()).unwrap();arena.metadata_mut(body).add_flags(flag);
 let mut result=transform_nodes(arena,vec![TransformRoot::SourceFile(source)],Vec::new(),false).unwrap();
 let out=create_printer(PrinterOptions::new(NewLineKind::LineFeed)).print(&mut result,PrintRequest::SourceFile(source),None).unwrap();
 println!("{}",serde_json::json!({"name":name,"text":out.text()}));
 }
}
